import { Component, OnInit } from '@angular/core';
declare var $;
@Component({
  selector: 'app-appointment',
  templateUrl: './appointment.component.html',
  styleUrls: ['./appointment.component.scss']
})
export class AppointmentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    $(document).on('click','.myButton',function(){
      $('.myButton').addClass('active');
      $(".myCheckBox").prop("checked", true); 
    });
    
    $(document).on('click','.myButton.active',function(){
      $('.myButton').removeClass('active');
      $(".myCheckBox").prop("checked", false); 
    });
  }

}
