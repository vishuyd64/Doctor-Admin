import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ecg',
  templateUrl: './ecg.component.html',
  styleUrls: ['./ecg.component.scss']
})
export class EcgComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
