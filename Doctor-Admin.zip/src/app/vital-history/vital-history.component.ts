import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vital-history',
  templateUrl: './vital-history.component.html',
  styleUrls: ['./vital-history.component.scss']
})
export class VitalHistoryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
