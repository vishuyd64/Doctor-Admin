import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CompleteDxRxComponent } from './complete-dx-rx.component';

describe('CompleteDxRxComponent', () => {
  let component: CompleteDxRxComponent;
  let fixture: ComponentFixture<CompleteDxRxComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CompleteDxRxComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CompleteDxRxComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
