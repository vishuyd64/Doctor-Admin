import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-complete-dx-rx',
  templateUrl: './complete-dx-rx.component.html',
  styleUrls: ['./complete-dx-rx.component.scss']
})
export class CompleteDxRxComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
