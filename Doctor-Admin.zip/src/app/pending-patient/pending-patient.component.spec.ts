import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PendingPatientComponent } from './pending-patient.component';

describe('PendingPatientComponent', () => {
  let component: PendingPatientComponent;
  let fixture: ComponentFixture<PendingPatientComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PendingPatientComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PendingPatientComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
