import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pending-patient',
  templateUrl: './pending-patient.component.html',
  styleUrls: ['./pending-patient.component.scss']
})
export class PendingPatientComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
