import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PastResultGraphComponent } from './past-result-graph.component';

describe('PastResultGraphComponent', () => {
  let component: PastResultGraphComponent;
  let fixture: ComponentFixture<PastResultGraphComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PastResultGraphComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PastResultGraphComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
