import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AppointmentComponent } from './appointment/appointment.component';
import { CalenderComponent } from './calender/calender.component';
import { CheckinHistoryComponent } from './checkin-history/checkin-history.component';
import { CompleteDxRxComponent } from './complete-dx-rx/complete-dx-rx.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { EcgComponent } from './ecg/ecg.component';
import { LabsComponent } from './labs/labs.component';
import { LoginComponent } from './login/login.component';
import { PastResultGraphComponent } from './past-result-graph/past-result-graph.component';
import { PastResultComponent } from './past-result/past-result.component';
import { PatientDataComponent } from './patient-data/patient-data.component';
import { PatientsComponent } from './patients/patients.component';
import { PendingPatientComponent } from './pending-patient/pending-patient.component';
import { ProfileComponent } from './profile/profile.component';
import { SettingsComponent } from './settings/settings.component';
import { TestDetailsComponent } from './test-details/test-details.component';
import { VideoSessionsComponent } from './video-sessions/video-sessions.component';
import { VitalHistoryComponent } from './vital-history/vital-history.component';
 
const routes: Routes = [
  { path: '', component: LoginComponent },
  { path: 'dashboard', component: DashboardComponent },
  { path: 'pending-patients', component: PendingPatientComponent },
  { path: 'patients', component: PatientsComponent },
  { path: 'patients-data', component: PatientDataComponent },
  { path: 'vital-history', component: VitalHistoryComponent },
  { path: 'ecg', component: EcgComponent },
  { path: 'labs', component: LabsComponent },
  { path: 'DX-RX', component: CompleteDxRxComponent },
  { path: 'checkin-history', component: CheckinHistoryComponent },
  { path: 'test-detail', component: TestDetailsComponent },
  { path: 'past-result', component: PastResultComponent },
  { path: 'past-result-graph', component: PastResultGraphComponent },
  { path: 'calender', component: CalenderComponent },
  { path: 'login', component: LoginComponent },
  { path: 'appointment', component: AppointmentComponent },
  { path: 'video-sessions', component: VideoSessionsComponent },
  { path: 'profile', component: ProfileComponent },
  { path: 'settings', component: SettingsComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
