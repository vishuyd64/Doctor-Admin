import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-past-result',
  templateUrl: './past-result.component.html',
  styleUrls: ['./past-result.component.scss']
})
export class PastResultComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
