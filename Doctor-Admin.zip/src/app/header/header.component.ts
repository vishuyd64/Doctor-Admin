import { Component, OnInit } from '@angular/core';
declare var $;
@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    function toggleFullscreen() {
      let elem = document.querySelector("html");
    
      if (!document.fullscreenElement) {
        elem.requestFullscreen().catch(err => {
        });
      } else {
        document.exitFullscreen();
      }
    }
$(document).on('click','.fullscreen',function(){
  toggleFullscreen();
});
  }

}
