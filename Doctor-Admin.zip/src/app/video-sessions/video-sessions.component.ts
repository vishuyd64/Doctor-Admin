import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-video-sessions',
  templateUrl: './video-sessions.component.html',
  styleUrls: ['./video-sessions.component.scss']
})
export class VideoSessionsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
