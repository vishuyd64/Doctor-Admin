import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { VideoSessionsComponent } from './video-sessions.component';

describe('VideoSessionsComponent', () => {
  let component: VideoSessionsComponent;
  let fixture: ComponentFixture<VideoSessionsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ VideoSessionsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VideoSessionsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
