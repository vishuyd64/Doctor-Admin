import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-checkin-history',
  templateUrl: './checkin-history.component.html',
  styleUrls: ['./checkin-history.component.scss']
})
export class CheckinHistoryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
