import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
 
 
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NgApexchartsModule } from "ng-apexcharts";
import { DashboardComponent } from './dashboard/dashboard.component';
import { PendingPatientComponent } from './pending-patient/pending-patient.component';
import { PatientsComponent } from './patients/patients.component';
import { HeaderComponent } from './header/header.component';
import { SidenavComponent } from './sidenav/sidenav.component';
import { PatientDataComponent } from './patient-data/patient-data.component';
import { VitalHistoryComponent } from './vital-history/vital-history.component';
import { EcgComponent } from './ecg/ecg.component';
import { LabsComponent } from './labs/labs.component';
import { CompleteDxRxComponent } from './complete-dx-rx/complete-dx-rx.component';
import { CheckinHistoryComponent } from './checkin-history/checkin-history.component';
import { TestDetailsComponent } from './test-details/test-details.component';
import { PastResultComponent } from './past-result/past-result.component';
import { PastResultGraphComponent } from './past-result-graph/past-result-graph.component';
import { CalenderComponent } from './calender/calender.component';
import { LoginComponent } from './login/login.component';
import { AppointmentComponent } from './appointment/appointment.component';
import { VideoSessionsComponent } from './video-sessions/video-sessions.component';
import { ProfileComponent } from './profile/profile.component';
import { SettingsComponent } from './settings/settings.component';


 import { FullCalendarModule } from '@fullcalendar/angular';

@NgModule({
  declarations: [
    AppComponent,
    DashboardComponent,
    PendingPatientComponent,
    PatientsComponent,
    HeaderComponent,
    SidenavComponent,
    PatientDataComponent,
    VitalHistoryComponent,
    EcgComponent,
    LabsComponent,
    CompleteDxRxComponent,
    CheckinHistoryComponent,
    TestDetailsComponent,
    PastResultComponent,
    PastResultGraphComponent,
    CalenderComponent,
    LoginComponent,
    AppointmentComponent,
    VideoSessionsComponent,
    ProfileComponent,
    SettingsComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule, 
    NgApexchartsModule, 
    FullCalendarModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
